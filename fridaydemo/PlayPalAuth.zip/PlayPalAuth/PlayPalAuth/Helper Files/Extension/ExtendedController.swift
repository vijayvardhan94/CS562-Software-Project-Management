


import UIKit

class ExtendedController: UIViewController {

    private var isLoaded = false;
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.LanguageSet()
         self.NavBarIcon()
        
        
        
    }
    func NavBarIcon()
    {
        
        
        
        let Notification = UIBarButtonItem(image: UIImage.ionicon(with: .androidCart, textColor: UIColor.black, size: CGSize(width: 40, height: 30)), style: .plain, target: self, action: #selector(Notification_Action))
        Notification.tintColor = UIColor.black
        self.tabBarController?.navigationItem.rightBarButtonItems = [Notification]
        
        
        
    }
   
    @objc func Notification_Action(){
        
        
        
    }
    
    @objc func LanguageSet(){
        
        
        
    }
    
    func viewDidLayout(){
    }
}
