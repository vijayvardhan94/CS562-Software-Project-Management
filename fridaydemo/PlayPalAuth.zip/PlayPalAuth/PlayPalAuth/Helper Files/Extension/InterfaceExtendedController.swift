


import UIKit
import IoniconsKit
import GeometricLoaders


class InterfaceExtendedController : ExtendedController {
     var navBackgroundColor : UIColor?
    
    
    func NavigationBarTitleName(Title : String)
    {
        self.title = ""
    }
    
    func PaintNavigationBar(TitleColor:UIColor,BackgroundColor:UIColor,BtnColor:UIColor)
    {
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: TitleColor]
        
        // Navigation bar color
        self.navigationController?.navigationBar.barTintColor = BackgroundColor
        
        self.navBackgroundColor = BackgroundColor
        // Back button Txet Color
        self.navigationController!.navigationBar.tintColor = BtnColor
        
    }
    
    
    func RightActionButton(Title:String){
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 70, height: 20))
        button.contentVerticalAlignment = .bottom
        button .setTitle(Title, for: .normal)
        button.addTarget(self, action: #selector(rightButtonAction), for: .touchUpInside)
        button.sizeToFit()
        let barItem = UIBarButtonItem(customView: button)
        var items = self.navigationItem.rightBarButtonItems ?? [UIBarButtonItem]();
        items.append(barItem)
        self.navigationItem.rightBarButtonItems = items
    }
    
    @objc func rightButtonAction(){
        
        
        
    }
   
    func alert(_ message: String)
    {
        var mess = ""
        if message != ""
        {
            mess = message
        }
        else
        {
            mess = "SomeThing Went Wrong"
        }
        let titleName = "PlayPalAuth"
        self.popupAlert(title: titleName, message: mess, actionTitles:["ok"], actions:[{action1 in
            print("ok")
            }, nil])
        
    }
    
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    
    func paintNavigationTitle(title : String){
        
        let label = UILabel()
        label.backgroundColor = UIColor.clear
        label.font = UIFont (name: "HelveticaNeue", size: 20)
        label.textAlignment = .center
        label.textColor = UIColor.white
        label.text = title
        label.sizeToFit()
        self.navigationItem.titleView = label
    }
    
    func paintBackButton(_ ImageName : String){
        
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        let image = UIImage(named: ImageName)
        button.imageView?.contentMode = .scaleAspectFit
        button.setImage(image, for: UIControl.State.normal)
        button.imageEdgeInsets =  UIEdgeInsets(top: 0.0,left: -30.0, bottom: 0.0,right: 0.0)
        button.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
        let barButton = UIBarButtonItem(customView: button)
        self.navigationItem.leftBarButtonItem = barButton
    }
    
   
    
    
    func removeRightActionButton(){
        self.navigationItem.rightBarButtonItems = nil
    }
    
  
    
    @objc func backTapped(){
        let _ = self.navigationController?.popViewController(animated: true)
    }
}


