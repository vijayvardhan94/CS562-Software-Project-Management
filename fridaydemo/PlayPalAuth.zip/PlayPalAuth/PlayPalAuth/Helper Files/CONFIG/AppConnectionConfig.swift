
import Foundation
class AppConnectionConfig:NSObject{
    
    
    
}
