//
//  People_List.swift
//  PlayPalAuth
//
//  Created by MAC on 07/02/19.
//  Copyright © 2019 DigitalMenti. All rights reserved.
//

import UIKit
import SDWebImage
import Letters
import MMDrawerController
import Firebase
import FirebaseDatabase
import GeometricLoaders

class People_List: InterfaceExtendedController {
    
    let ref = Database.database().reference().child("users")
    var MatchPeople : [String] = []
    var dateString : String = ""
    var data : [NSDictionary] = []
    var geometricLoader = GeometricLoader()

    @IBOutlet weak var mTableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        geometricLoader = Infinity.createGeometricLoader()

        geometricLoader.startAnimation()

        
        self.mTableview.delegate = self
        self.mTableview.dataSource = self
        self.mTableview.tableFooterView = UIView()
        self.mTableview.separatorStyle = .none
        mTableview.rowHeight = UITableView.automaticDimension
        mTableview.estimatedRowHeight = 100
        
        self.title = "Match People"
        
        
             let uid : String = UserDefaults.standard.object(forKey: "user_id") as! String
        
        ref.observeSingleEvent(of: .value, with: { snapshot in
            
    
            
            for childSnapshot in snapshot.children {
                
                let snap : DataSnapshot = childSnapshot as! DataSnapshot
                // print(snap.value)
                //print(snap.key)
                
                let values : NSArray = snap.value as! NSArray
                for dic in values{
                    let dict : NSDictionary = dic as! NSDictionary

                    let dater : String = dict["date_time"] as! String
                    let newUID : String = dict["user_id"] as! String
                    if newUID != uid{
                        if dater == self.dateString{
                            self.data.append(dict)
                        }
                    }
           
                }
                
          
                
            }
            
            var data2 : [NSDictionary] = []

            for dictr in self.data{
                let gameName : String = dictr["game_name"] as! String
                let filteredItems = self.MatchPeople.filter { $0 == gameName}
                if filteredItems.count != 0{
                    data2.append(dictr)
                }
            }
            
            self.data = data2
            
            
            if self.data.count == 0
            {
                self.alert("No Match Found")


            }
            
            self.mTableview.reloadData()
            
            self.geometricLoader.stopAnimation()

        })
        
      
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
}

extension People_List : UITableViewDelegate,UITableViewDataSource
{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TeamCell
        
        let dict  = data[indexPath.row]
        
        
        cell.viewShadow?.bottomViewShadow(ColorName: UIColor.gray)
        cell.imgUser?.setImage(string: dict["user_name"] as? String, color: nil, circular: true)
        cell.lblUserName.text = dict["user_name"] as? String
        cell.lblMessage.text = "\(dict["game_name"] as? String ?? "") \(":") \(dict["date_time"] as? String ?? "")"
        cell.selectionStyle = .none
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        
        
        
    }
 
    
}



extension People_List
{
    class func instance()->People_List?{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "People_List") as? People_List
        
        
        return controller
    }
}

