//
//  HomeViewControler.swift
//  PlayPalAuth
//
//  Created by MAC on 07/02/19.
//  Copyright © 2019 DigitalMenti. All rights reserved.
//

import UIKit
import MMDrawerController

class HomeViewControler: UIViewController,DateTimePickerDelegate {
    @IBOutlet weak var mTableView: UITableView!
    
    var Sports_Name = ["Badminton", "Ball badminton", "Biribol", "Bossaball", "Fistball", "Footbag net","Football tennis","Footvolley","Rocball"]
     var Selected_Sports = [Bool]()
    var Date_Picker = UIDatePicker()
    var FakeArray = [String]()
    var Date_string : String = ""


    override func viewDidLoad() {
        super.viewDidLoad()

        
        UserDefaults.standard.set("FindMatches", forKey: "Class")
        UserDefaults.standard.synchronize()
        
        
        
         NotificationCenter.default.addObserver(self, selector: #selector(FindMatches), name: NSNotification.Name( "FindMatches"), object: nil)

        self.mTableView.delegate = self
        self.mTableView.dataSource = self
        self.mTableView.tableFooterView = UIView()
        self.view.backgroundColor = OffWhiteColor()
        
        self.title = "Sports Name"
        self.Selected_Sports = Array(repeating: false, count: self.Sports_Name.count )
        self.FakeArray = Array(repeating: "", count: self.Sports_Name.count )

        
    }
    
    @objc func FindMatches()
    {
        
        
        if Date_string == ""
        {
            
            Date_string = CurrentDate()
            
        }
        
        let filteredItems = self.FakeArray.filter { $0 != "" }
        
        print(filteredItems)
        
        
        
        guard let obj_People_List = People_List.instance()
            else{return}
        
        obj_People_List.dateString = Date_string
        obj_People_List.MatchPeople =  filteredItems
        self.navigationController?.pushViewController(obj_People_List, animated: true)
        
        Date_string = ""

        
    }
    
    
    func CurrentDate()->String{
        let currentDateTime = Date()
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        
        formatter.dateFormat = "HH:mm dd/MM/yyyy"
        
        
        return formatter.string(from: currentDateTime)
        
    }

override func viewWillAppear(_ animated: Bool) {
    
    
    let btSlider = UIBarButtonItem(image: UIImage.ionicon(with: .androidMenu, textColor: UIColor.red, size: CGSize(width: 30, height: 30)), style: .plain, target: self, action: #selector(OpenSlider))
    btSlider.tintColor = UIColor.black
    navigationItem.leftBarButtonItem = btSlider
    
    
    
    let NextButton = UIBarButtonItem(image: UIImage.ionicon(with: .androidArrowForward, textColor: UIColor.red, size: CGSize(width: 30, height: 30)), style: .plain, target: self, action: #selector(nextButton))
    NextButton.tintColor = UIColor.black
    navigationItem.rightBarButtonItem = NextButton
    
    

    
    
    
}
    
    @objc func nextButton() {
        
        let filteredItems = self.Selected_Sports.filter { $0 == true }
        
        
        print(filteredItems.count)
        
        if filteredItems.count == 0
        {
            // create the alert
            let alert = UIAlertController(title: "Please select a Game to continue", message: nil, preferredStyle: UIAlertController.Style.alert)
            // add an action (button)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
            
     else
        {
        
        let min = Date().addingTimeInterval(-60 * 60 * 24 * 7)
        let max = Date().addingTimeInterval(60 * 60 * 24 * 7)
        let picker = DateTimePicker.create(minimumDate: min, maximumDate: max)
        picker.includeMonth = true // if true the month shows at bottom of date cell
        picker.highlightColor = UIColor(red: 255.0/255.0, green: 138.0/255.0, blue: 138.0/255.0, alpha: 1)
        picker.darkColor = UIColor.darkGray
        picker.doneButtonTitle = "Find Match"
        picker.doneBackgroundColor = UIColor(red: 255.0/255.0, green: 138.0/255.0, blue: 138.0/255.0, alpha: 1)
        picker.completionHandler = { date in
            let formatter = DateFormatter()
            formatter.dateFormat = "hh:mm aa dd/MM/YYYY"
            self.title = formatter.string(from: date)
        }
        picker.delegate = self
        picker.show()
            
        }
        
        
        
        
    }
    
    
    
    @objc func OpenSlider(){
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.drawerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
}
    
    func dateTimePicker(_ picker: DateTimePicker, didSelectDate: Date) {
        //title = picker.selectedDateString
        
        
         self.title = ""
        
        Date_string = picker.selectedDateString
        
       // print(picker.selectedDateString)
        
        self.title = "Sports Name"
        
        
        
    }
    
   
}



extension HomeViewControler: UITableViewDelegate,UITableViewDataSource
{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SportseCell") as! SportseCell
        cell.SportsName.font = UIFont.systemFont(ofSize: 20)
        cell.SportsName.textColor = UIColor.black
        cell.SportsName.text = Sports_Name[indexPath.row]
        cell.backgroundColor = UIColor.clear
        cell.selectionStyle = .none
        
        if !Selected_Sports[indexPath.row] {
            cell.accessoryType = .none
        } else if Selected_Sports[indexPath.row] {
            cell.accessoryType = .checkmark
        }
        
        return cell
    }
    
    
    //Table view delegates
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int
    {
        
        return Sports_Name.count
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if let cell = tableView.cellForRow(at: indexPath as IndexPath) {
            if cell.accessoryType == .checkmark {
                cell.accessoryType = .none
                Selected_Sports[indexPath.row] = false
                FakeArray[indexPath.row] = ""
            } else {
                cell.accessoryType = .checkmark
                Selected_Sports[indexPath.row] = true
                FakeArray[indexPath.row] = Sports_Name[indexPath.row]
            }
        }
    }
    
  
}

extension HomeViewControler
{
    class func instance()->HomeViewControler?{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "HomeViewControler") as? HomeViewControler
        
        
        return controller
    }
}
