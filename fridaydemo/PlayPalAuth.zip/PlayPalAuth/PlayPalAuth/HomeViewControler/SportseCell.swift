//
//  SportseCell.swift
//  PlayPalAuth
//
//  Created by MAC on 07/02/19.
//  Copyright © 2019 DigitalMenti. All rights reserved.
//

import UIKit

class SportseCell: UITableViewCell {

    @IBOutlet weak var SportsName: UILabel!
    

}
