


import UIKit

 func ColorValue(Rvalue:CGFloat,Gvalue:CGFloat,Bvalue:CGFloat,alphavalue:CGFloat) -> UIColor {
        
         let Color = UIColor(red: Rvalue/255.0, green: Gvalue/255.0, blue: Bvalue/255.0, alpha: alphavalue)
        return Color
    
}
func WhiteColor() -> UIColor {
    
    let Color = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    return Color
}

func OffWhiteColor() -> UIColor {
    
    let Color = UIColor(red: 248.0/255.0, green: 250.0/255.0, blue: 251.0/255.0, alpha: 1.0)
    return Color
}




