
import UIKit

public class KYEmbedMainControllerSegue: UIStoryboardSegue {
    
    final override public func perform() {
        if let sourceViewController = source as? KYDrawerController {
            sourceViewController.mainViewController = destination
        } else {
            assertionFailure("SourceViewController must be KYDrawerController!")
        }
    }
    
}
