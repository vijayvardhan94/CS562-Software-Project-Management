//
//  Date_Range.swift
//  PlayPalAuth
//
//  Created by MAC on 11/03/19.
//  Copyright © 2019 DigitalMenti. All rights reserved.
//

import UIKit
import FirebaseDatabase
import GeometricLoaders

class Date_Range:InterfaceExtendedController {
    
    @IBOutlet fileprivate var txtRescheduled_date : UITextField?
    @IBOutlet fileprivate var txtFromTime : UITextField?
    @IBOutlet fileprivate var txtToTime : UITextField?
    @IBOutlet fileprivate var outletSubmitBtn : UIButton!
    fileprivate let datePicker = UIDatePicker()
    fileprivate var tags : Int = 0
    var idNo : Int = 0
      var Class_name : String = ""
    var title_name : String = ""
    var date : String  = ""
    var fromTime : String = ""
    var toTime : String = ""
    var GamesArrayValue = [String]()
    
    let GameArray = NSMutableArray ()
    var Selected_Game_Array = [String : Any]()

    let ref = Database.database().reference()
    var geometricLoader = GeometricLoader()

    override func viewDidLoad() {
        super.viewDidLoad()
        geometricLoader = Infinity.createGeometricLoader()

     
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
  
        
    }
    @objc override func LanguageSet(){
        
        NavigationBarTitleName(Title: title_name)
    }
    
    @objc fileprivate func addTapped()
    {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction fileprivate func submitBtn(sender : UIButton)
    {
        if txtRescheduled_date!.text != "" && txtFromTime!.text != "" && txtToTime!.text != ""
        {
            
            
            
     if Class_name == "AddSports"
          {
            
            AddGameData()
            
    
            }
            else
         {
            
                    let filteredItems = self.GamesArrayValue.filter { $0 != "" }
            
                    print(filteredItems)
            
            
            
                    guard let obj_People_List = People_List.instance()
                        else{return}
            
            
            
            
                  obj_People_List.date_str = "\(self.txtRescheduled_date!.text!), \(self.txtFromTime!.text!)"
                  obj_People_List.fromTime_str = "\(self.txtRescheduled_date!.text!), \(self.txtFromTime!.text!)"
                 obj_People_List.toTime_str = "\(self.txtRescheduled_date!.text!), \(self.txtToTime!.text!)"
                    obj_People_List.MatchPeople =  filteredItems
                    self.navigationController?.pushViewController(obj_People_List, animated: true)
            
        
            }
                
                
                
                
               
            
        }
    }
    
    
    
    
    func AddGameData() {
        
        
        
        
        self.geometricLoader.startAnimation()
        
        
        
        let filteredItems = self.GamesArrayValue.filter { $0 != "" }
        
        print(filteredItems)
        
        for index in 0..<(filteredItems.count) {
            
            
            let to_time = "\(self.txtRescheduled_date!.text!), \(self.txtToTime!.text!)"
             let from_time = "\(self.txtRescheduled_date!.text!), \(self.txtFromTime!.text!)"
            
            
            self.Selected_Game_Array = ["game_name":filteredItems[index],"FromTime":"\(self.txtFromTime!.text!)","Start_time":from_time,"ToTime":"\(self.txtToTime!.text!)","End_time":to_time,"user_id":(UserDefaults.standard.value(forKey: "user_id") as! String),"user_name":(UserDefaults.standard.value(forKey: "name") as! String)]
            self.GameArray.add(self.Selected_Game_Array)
            
        }
        
        self.ref.child("users").child((UserDefaults.standard.value(forKey: "user_id") as! String)).setValue(self.GameArray)
        
        
        self.geometricLoader.stopAnimation()
        
        
        
        let uiAlert = UIAlertController(title: "PlayPalAuth", message: "Add matches successfully", preferredStyle: UIAlertController.Style.alert)
        self.present(uiAlert, animated: true, completion: nil)
        
        uiAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
            
            self.navigationController?.popViewController(animated: true)
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: self.Class_name), object: nil)
            
            
            
            
        }))
        
  
        
    }
    
    
}
extension Date_Range : UITextFieldDelegate
{
    
    func showTimePicker(txt : UITextField){
        //Formate Date
        
        tags = txt.tag
        datePicker.minimumDate = Date()
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        if txt.tag == 1
        { datePicker.datePickerMode = .date
            txtRescheduled_date?.inputAccessoryView = toolbar
            txtRescheduled_date?.inputView = datePicker
            
        }
        else if txt.tag == 2
        {
            datePicker.datePickerMode = .time
            txtFromTime?.inputAccessoryView = toolbar
            txtFromTime?.inputView = datePicker
        }
        else if txt.tag == 3
        {
            datePicker.datePickerMode = .time
            txtToTime?.inputAccessoryView = toolbar
            txtToTime?.inputView = datePicker
        }
        
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        print("textField-----> ",textField.tag)
        showTimePicker(txt: textField)
        //tags = textField.tag
    }
    
    @objc func donedatePicker(){
        
        
        let formatter = DateFormatter()
        switch tags {
        case 1:
            formatter.dateFormat = "MMM dd,yyyy"
            
            txtRescheduled_date?.text = formatter.string(from: datePicker.date)
            break
        case 2:
            formatter.dateFormat = "hh:mm a"
            txtFromTime?.text = formatter.string(from: datePicker.date)
            break
        case 3:
            formatter.dateFormat = "hh:mm a"
            txtToTime?.text = formatter.string(from: datePicker.date)
            break
        default:
            print("invalid")
        }
        
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
}

extension Date_Range
{
    class func instance()->Date_Range?{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "Date_Range") as? Date_Range
        //self.definesPresentationContext = true
        
        return controller
    }
}


