

import UIKit

class TeamCell: UITableViewCell {

     @IBOutlet var viewShadow : UIView?
    var gender : String = "Male_PH"
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblChatLogo: UILabel!
    @IBOutlet var lblStatus : UILabel?
 //   @IBOutlet var viewShadow : UIView?

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
       imgUser.createCircleForView()
    }
}
