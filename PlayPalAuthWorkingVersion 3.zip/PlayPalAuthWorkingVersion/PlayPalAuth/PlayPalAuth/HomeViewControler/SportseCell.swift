//
//  SportseCell.swift
//  PlayPalAuth
//
//  
//

import UIKit

class SportseCell: UITableViewCell {

    @IBOutlet weak var SportsName: UILabel!
    

}
