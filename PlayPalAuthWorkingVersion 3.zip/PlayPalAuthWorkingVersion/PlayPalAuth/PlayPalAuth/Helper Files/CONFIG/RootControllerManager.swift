

import Foundation
import MMDrawerController
import UIKit

class RootControllerManager : NSObject{
    
    
    
    var drawerContainer: MMDrawerController?
    
    func setRoot(){
        
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let window = appDelegate?.window
        
       
        if(UserDefaults.standard.value(forKey: "NewUser") == nil){
            guard let controller = LoginViewController.instance()
                else{
                    return
            }
            let nav = UINavigationController(rootViewController: controller)
            window?.rootViewController = nav
            return
        }
        
        appDelegate?.buildNavigationDrawer()
        return


        
    }
    
    func resetDefaults() {
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()
        dictionary.keys.forEach { key in
            defaults.removeObject(forKey: key)
        }
    }
    
}

