
import UIKit
import IoniconsKit
import MMDrawerController
import SDWebImage
import GoogleSignIn
import FirebaseAuth
import Firebase

class MenuVC: InterfaceExtendedController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var mTableView: UITableView!
    @IBOutlet weak var backHolderImage: UIImageView!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserAddress: UILabel!
    
    var gender : String? = "Male_PH"
    var arrMenuList = NSArray()
    var arrMenuList_IMG : [Ionicons] = [.iosBaseballOutline,.androidStarOutline,.androidExit]
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mTableView.delegate = self
        self.mTableView.dataSource = self
        self.mTableView.tableFooterView = UIView()
        self.view.backgroundColor = OffWhiteColor()
        
        
           arrMenuList = ["Sports","Interest area","Logout"]
        
    setDetails()
    }
    @objc func setDetails()
    {
        
        lblUserName.text = (UserDefaults.standard.value(forKey: "name") as! String)
        let imageUrl =   URL(string: (UserDefaults.standard.value(forKey: "image") as! String))
        userImage!.sd_setImage(with: imageUrl, placeholderImage:UIImage(imageLiteralResourceName: gender!), options: .cacheMemoryOnly, completed: nil)
        }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       self.userImage.createCircleForView()
        
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenuList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell") as! MenuTableViewCell
        
        
        cell.Title_LBL.font = UIFont.systemFont(ofSize: 20)
       cell.Title_LBL.textColor = ColorValue(Rvalue:61, Gvalue: 140, Bvalue: 250, alphavalue: 0.9)
      cell.Title_LBL.text = arrMenuList[indexPath.row] as? String
        
        cell.Title_IMG.image =   UIImage.ionicon(with: arrMenuList_IMG[indexPath.row], textColor: UIColor.black, size: CGSize(width: 70, height: 70))
            
            cell.selectionStyle = .none
            
        
        cell.backgroundColor = OffWhiteColor()
        
        return cell
    }
    
    
    
    
    @objc func buttonClicked(sender: UIButton!) {
        
        self.logOut()
        
      
    }
    
   
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.row == 2
        {
            logOut()
        }
        else if indexPath.row == 0
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let OBJHomeViewControler = storyboard.instantiateViewController(withIdentifier: "HomeViewControler") as? HomeViewControler
            let aboutNavController = UINavigationController(rootViewController: OBJHomeViewControler!)
            let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.drawerContainer!.centerViewController = aboutNavController
            appDelegate.drawerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
        }
        else if indexPath.row == 1
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let OBJAdd_Interests = storyboard.instantiateViewController(withIdentifier: "Add_Interests") as? Add_Interests
            let aboutNavController = UINavigationController(rootViewController: OBJAdd_Interests!)
            let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.drawerContainer!.centerViewController = aboutNavController
            appDelegate.drawerContainer?.toggle(MMDrawerSide.left, animated: true, completion: nil)
        }
        
        
       
     
    }
    
    
    func logOut () {
        
        self.popupAlert(title:"Are you sure you want to log out?" , message: nil, actionTitles: ["NO","YES"], actions: [{action1 in
            return
            },{action2 in
                GIDSignIn.sharedInstance().signOut()
                try! Auth.auth().signOut()
                 RootControllerManager().resetDefaults()
                    RootControllerManager().setRoot()
                    return
               
            }, nil])
        
    }
    
    func navToTabBar (vc:UIViewController) {
     //   selectedIndexTab = 0
        elDrawer?.mainViewController = UINavigationController(rootViewController: vc)
        elDrawer?.setDrawerState(.closed, animated: true)
    }
   
}
