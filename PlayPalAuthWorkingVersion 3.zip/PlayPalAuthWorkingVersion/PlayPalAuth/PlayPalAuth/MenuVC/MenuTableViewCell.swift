

import UIKit

class MenuTableViewCell: UITableViewCell {
    
    @IBOutlet weak var Title_IMG: UIImageView!
    @IBOutlet weak var Title_LBL: UILabel!
    
}
