

import UIKit
import GoogleSignIn
import MMDrawerController
import Firebase
import FirebaseDatabase

var elDrawer: KYDrawerController?
var indexvalue:NSInteger = 0
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    
    var drawerContainer: MMDrawerController?

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        printDocumentsDirectory()
        FirebaseApp.configure()
        

        
        UserDefaults.standard.set("FindMatches", forKey: "Class")
        UserDefaults.standard.synchronize()
        
        
        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
      //  GIDSignIn.sharedInstance()?.delegate = self
         sleep(2)
        
        
   
        RootControllerManager().setRoot()
        return true
    }

    
   
    func buildNavigationDrawer()
    {
        
        // Instantiate Main.storyboard
        let mainStoryBoard:UIStoryboard = UIStoryboard(name:"Main", bundle:nil)
        
        // Create View Controllers
        let mainPage:UINavigationController = mainStoryBoard.instantiateViewController(withIdentifier: "nav") as! UINavigationController
        
        let leftSideMenu:MenuVC = mainStoryBoard.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
        
        
        // Cerate MMDrawerController
        drawerContainer = MMDrawerController(center: mainPage, leftDrawerViewController: leftSideMenu, rightDrawerViewController: nil)
        
        drawerContainer!.openDrawerGestureModeMask = MMOpenDrawerGestureMode.panningCenterView
        drawerContainer!.closeDrawerGestureModeMask = MMCloseDrawerGestureMode.panningCenterView
        
        // Assign MMDrawerController to our window's root ViewController
        window?.rootViewController = drawerContainer
        
    }
    
    func makingRoot(_ strRoot: String) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        window = UIWindow(frame: UIScreen.main.bounds)
        
        if (strRoot == "initial") {
            
            let obj: UINavigationController? = storyboard.instantiateViewController(withIdentifier: storyboardID.navigationIdentifier) as? UINavigationController
            
            window?.rootViewController = obj
            
        } else {
            
            elDrawer = (storyboard.instantiateViewController(withIdentifier: storyboardID.kyDrawerIdentifierSegue) as! KYDrawerController)
            window?.rootViewController = elDrawer
            
        }
        
        window?.makeKeyAndVisible()
        
        UIView.transition(with: window!, duration: 0.3, options: .transitionCrossDissolve, animations: nil, completion: { _ in })
        
        
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        return GIDSignIn.sharedInstance().handle(url, sourceApplication: sourceApplication, annotation: annotation)
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        let sourceApplication = options[UIApplication.OpenURLOptionsKey.sourceApplication] as? String
        let annotation = options[UIApplication.OpenURLOptionsKey.annotation]
        return GIDSignIn.sharedInstance().handle(url, sourceApplication: sourceApplication, annotation: annotation)
    }
    
    private func printDocumentsDirectory() {
        let fileManager = FileManager.default
        if let documentsDir = fileManager.urls(for: .documentDirectory, in: .userDomainMask).last {
            print("Documents directory: \(documentsDir.absoluteString)")
        } else {
            print("Error: Couldn't find documents directory")
        }
    }
}

