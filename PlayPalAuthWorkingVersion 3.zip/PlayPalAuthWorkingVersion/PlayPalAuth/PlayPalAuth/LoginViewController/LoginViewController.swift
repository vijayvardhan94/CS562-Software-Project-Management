
import UIKit
import IoniconsKit
import GoogleSignIn
import GoogleAPIClientForREST
import FirebaseAuth
import Firebase
import GeometricLoaders
class LoginViewController: InterfaceExtendedController {

    @IBOutlet weak var viewShadow: UIView!
    var geometricLoader = GeometricLoader()

    @IBOutlet weak var User_Name_LBL: UILabel!
    @IBOutlet weak var Password_LBL: UILabel!
    @IBOutlet weak var ImgEmailValidationCheck : UIImageView!
    
    fileprivate let service = GTLRDriveService()
    
    //@IBOutlet weak var Remember_me_BTN: UIButton!
    @IBOutlet fileprivate var txtFieldEmail : UITextField!
    @IBOutlet fileprivate var txtFieldPassword : UITextField!
    @IBOutlet weak var Signin_BTN: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
       geometricLoader = Infinity.createGeometricLoader()
        
        self.viewShadow.dropShadow(color: .gray, cornerRadius: 10, opacity: 0.7, offSet: CGSize.init(width: 0.0, height: 0.0), radius: 5)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
         self.navigationController?.setNavigationBarHidden(true, animated: false)
       
    }
    
   
    
    
    @IBAction func Google_Login(_ sender: Any) {
        
        GIDSignIn.sharedInstance().delegate=self
        GIDSignIn.sharedInstance().uiDelegate=self
        GIDSignIn.sharedInstance().signIn()
        
        
    }
    
    
    // MARK: - Button Action
    
    @IBAction func btnActForLogin(_ sender: UIButton) {
        
        
        guard let email = self.txtFieldEmail.text, let password = self.txtFieldPassword.text else {
            
            
            
            self.alert("email/password can't be empty")
            
            
            return
        }
        
        
        geometricLoader.startAnimation()

        
        // Sign user in
        Auth.auth().signIn(withEmail: email, password: password, completion: { (authResult, error) in
            
            
            guard let user = authResult?.user, error == nil else {
                
                
                self.alert(error!.localizedDescription)
                self.geometricLoader.stopAnimation()
                
                return
            }
            
            
           
            
           
            var username = email.split(separator: "@")
            
            
            let userID = Auth.auth().currentUser!.uid
            
            self.SaveUserInformation(User_name: String(username[0]), User_email_id:email, User_Img: "",User_id:userID)
       
          })
       
        }
        
    @IBAction func btnActForSignup(_ sender: UIButton) {
        
        
        
        
        guard let email = self.txtFieldEmail.text, let password = self.txtFieldPassword.text else {
            
            
            
            self.alert("email/password can't be empty")
            
            
            return
        }
        
        geometricLoader.startAnimation()
        // Create the user with the provided credentials
        Auth.auth().createUser(withEmail: email, password: password, completion: { (authResult, error) in
            
            guard let user = authResult?.user, error == nil else {
                
                
                 self.alert(error!.localizedDescription)
                self.geometricLoader.stopAnimation()
               
                return
            }
            
            var username = email.split(separator: "@")
           
            
            let userID = Auth.auth().currentUser!.uid
            self.SaveUserInformation(User_name: String(username[0]), User_email_id:email, User_Img: "",User_id:userID)
            
        })
        
        
        
    }
    
}

extension LoginViewController
{
    func SaveUserInformation(User_name:String,User_email_id:String,User_Img:String,User_id:String){
        
        
        UserDefaults.standard.set("Yes", forKey: "NewUser")
        UserDefaults.standard.synchronize()
        
        
        UserDefaults.standard.set(User_email_id, forKey: "email")
        UserDefaults.standard.synchronize()
        
        UserDefaults.standard.set(User_name, forKey: "name")
        UserDefaults.standard.synchronize()
        
        UserDefaults.standard.set(User_id, forKey: "user_id")
        UserDefaults.standard.synchronize()
        
        
        UserDefaults.standard.set(User_Img, forKey: "image")
        UserDefaults.standard.synchronize()
        
        
        
        geometricLoader.stopAnimation()
        RootControllerManager().setRoot()
        

    }
}


extension LoginViewController
{
    class func instance()->LoginViewController?{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        return controller
    }
}


// MARK: - GIDSignInDelegate
extension LoginViewController: GIDSignInDelegate {
    
    

    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {

        self.geometricLoader.startAnimation()

        if let _ = error {
            
        } else {
            
            guard let idToken = user.authentication.idToken else{return}
            guard let Accesstoken = user.authentication.accessToken else{return}
            
            let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                           accessToken: Accesstoken)
            

            
            
            Auth.auth().signInAndRetrieveData(with: credential) { (authResult, error) in
                if let error = error {
                    self.geometricLoader.stopAnimation()
                    print(error)
                    
                    return
                }

                    var imageURL = ""
                    if user.profile.hasImage {
                        imageURL = String(user.profile.imageURL(withDimension: 100).absoluteString)
                        
                        }
                
                
                
                let userID = Auth.auth().currentUser!.uid
                
                self.SaveUserInformation(User_name: user.profile.name!, User_email_id: user.profile.email!, User_Img: imageURL,User_id: userID)
                
            }
            
            
        }
        
        
        
    }
}


// MARK: - GIDSignInUIDelegate
extension LoginViewController: GIDSignInUIDelegate {}
